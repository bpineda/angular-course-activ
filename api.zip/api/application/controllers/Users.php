<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller 
{

	public function init()
	{
		$arr_users = [];
		//$arr_users[] = ['id' => 1, 'name' => 'bernardo', 'email' => 'bernardopineda@activ.com.mx'];
		$arr_users['users'][] = array( 'id' => 0, 'name' => 'bernardo', 'email' => 'bernardopineda@activ.com.mx');
		$arr_users['users'][] = array( 'id' => 1, 'name' => 'wilfrido', 'email' => 'wilfrido@correo.com');
		$this->session->set_userdata( $arr_users );
	}

	public function index()
	{
		$user_data = $this->session->get_userdata('user');
		echo json_encode($user_data);

	}

	public function details($id)
	{
		$user_data = $this->session->get_userdata('user');
		echo json_encode($user_data['users'][$id]);		
	}

	public function create()
	{
		$contents = file_get_contents("php://input");
		parse_str(file_get_contents("php://input"),$_PUT);
		$user_data = $this->session->get_userdata('user');
		$index = max(array_keys($user_data['users']))+1; //count($user_data);
		$_PUT['id'] = $index;
		$user_data['users'][$index] = $_PUT;
		$this->session->set_userdata( $user_data );

	}

	public function update($id)
	{
		
		$user_data = $this->session->get_userdata('user');
		$_POST['id'] = $id;
		$user_data['users'][$id] = $_POST;
		$this->session->set_userdata( $user_data );

	}

	public function destroy($id)
	{
		$old_user_data = $this->session->get_userdata('user');
		$new_user_data = [];
		foreach($old_user_data['users'] as $id_user => $user)
		{
			if($id == $id_user)
			{
				CONTINUE;
			}

			$new_user_data['users'][$id_user] = $user;

		}
		$this->session->set_userdata( $new_user_data );		
		echo json_encode($new_user_data['users']);		
	}

}
